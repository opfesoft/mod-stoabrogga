Bat Mount (310% speed, fly everywhere)

Item ID 702000: Bat (grey)
Item ID 702001: Duskbat (brown)
Item ID 702002: Vampire Bat (violet)
Item ID 702003: Albino Bat (white)

If the flying mount should be restricted to Outland and Northrend change "AttributesExD" in Spell.dbc to 67108864.