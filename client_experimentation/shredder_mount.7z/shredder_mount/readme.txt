Shredder mounts

Item ID 702008: Shredder MK-873
Item ID 702009: Shredder MK-581