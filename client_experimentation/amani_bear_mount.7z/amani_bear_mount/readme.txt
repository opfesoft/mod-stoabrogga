Amani Bear mounts

Item ID 702005: Green Amani War Bear
Item ID 702006: Yellow Amani War Bear
Item ID 702007: Brown Amani War Bear