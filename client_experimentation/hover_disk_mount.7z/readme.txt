Hover Disk Mount (310% speed, fly everywhere)

Item ID 702004: Hover Disk

If the flying mount should be restricted to Outland and Northrend change "AttributesExD" in Spell.dbc to 67108864.